# ppt_template
Levy-Template

This file contains a basic template of how to use Quarto for presentations


